/**
 * Created by SunnyZheng on 3/27/16.
 */
public interface Observer {
    public void update(double[] data);
}
